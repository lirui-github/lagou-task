package com.lagou.sqlsession;

import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;

import java.lang.reflect.*;
import java.util.List;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/15 16:58
 * @Description: Version: 1.0
 */
public class DefaultSqlSession implements SqlSession {

    private Configuration configuration;

    public DefaultSqlSession(Configuration configuration) {
        this.configuration = configuration;
    }

    /**
     * 查询所有
     * @param statementid
     * @param params
     * @param <E>
     * @return
     * @throws Exception
     */
    @Override
    public <E> List<E> selectList(String statementid, Object... params) throws Exception {
        // 使用SimpleExecutor的query方法调用
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementid);
        List<Object> list = simpleExecutor.query(configuration,mappedStatement,params);
        return (List<E>) list;
    }

    /**
     * 查询单个元素
     * @param statementid
     * @param params
     * @param <T>
     * @return
     * @throws Exception
     */
    @Override
    public <T> T selectOne(String statementid, Object... params) throws Exception {
        List<Object> objects = selectList(statementid, params);
        if (objects!=null && objects.size()==1){
            return (T) objects.get(0);
        } else {
            throw new RuntimeException("查询结果为空或者返回结果过多。");
        }
    }

    /**
     * 更新
     * @param statementid
     * @param params
     * @return
     * @throws Exception
     */
    @Override
    public int update(String statementid, Object... params) throws Exception {
        // 使用SimpleExecutor的query方法调用
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementid);
        int updateNum = simpleExecutor.update(configuration,mappedStatement,params);
        return updateNum;
    }

    /**
     * 删除
     * @param statementid
     * @param params
     * @return
     * @throws Exception
     */
    @Override
    public int delete(String statementid, Object... params) throws Exception {
        return update(statementid, params);
    }

    /**
     * 新增
     * @param statementid
     * @param params
     * @return
     * @throws Exception
     */
    @Override
    public int insert(String statementid, Object... params) throws Exception {
        return update(statementid, params);
    }

    /**
     * 为dao接口生成代理实现类
     * @param mapperClass
     * @param <T>
     * @return
     */
    @Override
    public <T> T getMapper(Class<?> mapperClass) {

        // 使用JDK动态代理来为DAO接口生成代理对象，并返回
        Object proxyInstance = Proxy.newProxyInstance(DefaultSqlSession.class.getClassLoader(), new Class[]{mapperClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                // 底层还是执行JDBC代码，根据不同情况，来调用selectList或者selectOne
                // 准备参数1：statementId(sql语句的唯一标识)；namespace.id=接口全类名.方法名
                // 方法名:findAll()
                String className = method.getDeclaringClass().getName();
                String methodName = method.getName();
                String statementId = className + "." + methodName;

                // 准备参数2：params:args
                // 获取被调用方法的返回值类型
                Type genericReturnType = method.getGenericReturnType();
                // 判断是否进行了泛型类型参数化(说明返回的是一个集合)
                if (genericReturnType instanceof ParameterizedType){
                    List<Object> objects = selectList(statementId,args);
                    return objects;
                }

                // 新增
                if (methodName.indexOf("insert") >= 0){
                    return insert(statementId,args);
                }

                // 修改
                if (methodName.indexOf("update") >= 0){
                    return update(statementId,args);
                }

                // 删除
                if (methodName.indexOf("delete") >= 0){
                    return delete(statementId,args);
                }

                // 返回的不是一个集合
                return selectOne(statementId,args);
            }
        });

        return (T) proxyInstance;
    }
}
