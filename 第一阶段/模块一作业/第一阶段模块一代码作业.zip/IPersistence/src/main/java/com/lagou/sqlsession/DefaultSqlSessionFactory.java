package com.lagou.sqlsession;

import com.lagou.pojo.Configuration;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/15 16:50
 * @Description: Version: 1.0
 */
public class DefaultSqlSessionFactory implements SqlSessionFactory {
    private Configuration configuration;

    public DefaultSqlSessionFactory(Configuration configuration) {
        this.configuration = configuration;
    }

    @Override
    public SqlSession openSession() {
        return new DefaultSqlSession(configuration);
    }
}
