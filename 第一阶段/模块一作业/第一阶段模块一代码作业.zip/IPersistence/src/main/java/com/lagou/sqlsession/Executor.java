package com.lagou.sqlsession;

import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;

import java.util.List;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/15 17:57
 * @Description: Version: 1.0
 */
public interface Executor {

    <E> List<E> query(Configuration configuration, MappedStatement mappedStatement, Object[] params) throws Exception;

    int update(Configuration configuration, MappedStatement mappedStatement, Object[] params) throws Exception;
}
