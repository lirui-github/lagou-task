package com.lagou.sqlsession;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/15 15:07
 * @Description: Version: 1.0
 */
public interface SqlSessionFactory {
    SqlSession openSession();
}
