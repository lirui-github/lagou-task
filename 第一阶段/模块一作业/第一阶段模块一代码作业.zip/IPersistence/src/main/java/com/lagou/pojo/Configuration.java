package com.lagou.pojo;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/15 14:55
 * @Description: Version: 1.0
 */
public class Configuration {
    // 封裝DataSource
    private DataSource dataSource;
    // 封裝mappedStatement
    // key是statementid  value：封裝好的MappedStatement对象
    Map<String,MappedStatement> mappedStatementMap = new HashMap<>();

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, MappedStatement> getMappedStatementMap() {
        return mappedStatementMap;
    }

    public void setMappedStatementMap(Map<String, MappedStatement> mappedStatementMap) {
        this.mappedStatementMap = mappedStatementMap;
    }
}
