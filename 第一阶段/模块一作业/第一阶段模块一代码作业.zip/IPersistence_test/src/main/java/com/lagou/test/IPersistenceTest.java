package com.lagou.test;

import com.lagou.dao.IUserDao;
import com.lagou.io.Resources;
import com.lagou.pojo.User;
import com.lagou.sqlsession.SqlSession;
import com.lagou.sqlsession.SqlSessionFactory;
import com.lagou.sqlsession.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/15 14:46
 * @Description: Version: 1.0
 */
public class IPersistenceTest {

    @Test
    public void test() throws Exception {
        InputStream resourcesAsStream = Resources.getResourcesAsStream("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourcesAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 查询单个元素（sqlsession）
        /*User user = new User();
        user.setId(1);
        user.setUsername("小黑");
        User resultUser = sqlSession.selectOne("User.selectOne", user);
        System.out.println(resultUser);
        System.out.println("----------------------------------------");*/

        // 查询集合（sqlsession）
        /*List<User> users = sqlSession.selectList("User.selectList");
        for (User tempUser : users) {
            System.out.println(tempUser);
        }*/

        // 查询集合（getMapper）
        /*IUserDao userMapper = sqlSession.getMapper(IUserDao.class);
        List<User> allUserList = userMapper.findAll();
        for (User user : allUserList) {
            System.out.println(user);
        }*/

        // 条件查询（getMapper）
        //findByCondition(sqlSession);

        // 新增
        //insertUser(sqlSession);

        // 修改
        //updateUser(sqlSession);

        // 删除
        deleteUser(sqlSession);
    }

    /**
     * 删除用户信息
     * @param sqlSession
     */
    private void deleteUser(SqlSession sqlSession) {
        User user = new User();
        user.setId(5);
        IUserDao userMapper = sqlSession.getMapper(IUserDao.class);
        int deleteNum = userMapper.deleteUser(user);
        System.out.println("deleteNum="+deleteNum);
    }

    /**
     * 新增用户信息
     * @param sqlSession
     */
    private void insertUser(SqlSession sqlSession) {
        User user = new User();
        user.setId(5);
        user.setUsername("柳青");
        IUserDao userMapper = sqlSession.getMapper(IUserDao.class);
        int insertNum = userMapper.insertUser(user);
        System.out.println("insertNum="+insertNum);
    }

    /**
     * 修改操作
     * @param sqlSession
     */
    private void updateUser(SqlSession sqlSession) {
        User user = new User();
        user.setId(5);
        user.setUsername("柳青111");
        IUserDao userMapper = sqlSession.getMapper(IUserDao.class);
        int updateNum = userMapper.updateUser(user);
        System.out.println("updateUser="+updateNum);
    }

    /**
     * 条件查询
     * @return
     */
    private void findByCondition(SqlSession sqlSession) throws Exception {
        User user = new User();
        user.setId(2);
        //user.setUsername("李白");
        IUserDao userMapper = sqlSession.getMapper(IUserDao.class);
        User userResult = userMapper.findByCondition(user);
        System.out.println("findByCondition="+userResult);
    }
}
