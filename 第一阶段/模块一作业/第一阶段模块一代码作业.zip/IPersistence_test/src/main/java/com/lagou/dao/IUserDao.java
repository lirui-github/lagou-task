package com.lagou.dao;

import com.lagou.pojo.User;

import java.util.List;

/**
 * @Auther: lirui
 * @Date: 2020 2020/3/19 21:16
 * @Description: Version: 1.0
 */
public interface IUserDao {

    // 查询所有用户
    public List<User> findAll() throws Exception;

    // 条件查询
    public User findByCondition(User user) throws Exception;

    // 更新用户信息
    int updateUser(User user);

    // 新增用户信息
    int insertUser(User user);

    // 删除用户信息
    int deleteUser(User user);
}
